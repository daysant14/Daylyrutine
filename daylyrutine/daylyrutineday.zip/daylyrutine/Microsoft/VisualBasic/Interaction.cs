﻿namespace Microsoft.VisualBasic
{
    internal class Interaction
    {
    }
}